package com.example.springbootmovie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootMovieApplicationTests {

	@Test
	void contextLoads() {
	}

}
